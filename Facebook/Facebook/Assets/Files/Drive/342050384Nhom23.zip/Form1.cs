﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Load();
        }

        List<Room> roomA;
        List<Room> roomB;
        List<Room> roomC;

        List<string> categoies = new List<string>() { "A", "B", "C" };

        int WIDTH_BUTTON = 100;
        int HEIGHT_BUTTON = 100;
        string EMPTY = "Trống";
        string NOTEMPTY = "Không trống";
        Color COLOR_LABEL_ROOM_EMPTY = Color.Black;
        Color COLOR_LABEL_ROOM_NOTEMPTY = Color.Orange;

        Button buttonSelected;
        Room roomSelected;


        new void Load()
        {
            this.WindowState = FormWindowState.Maximized;

            roomA = new List<Room>();
            roomB = new List<Room>();
            roomC = new List<Room>();

            cbpCategory.DataSource = new List<string>(categoies);
            cbpStatus.DataSource = new List<string>() { EMPTY, NOTEMPTY };

        }

        int GetIDByCategory(string category)
        {
            switch (category)
            {
                case "A":
                    return roomA.Count() + 1;
                case "B":
                    return roomB.Count() + 1;
                default:
                    return roomC.Count() + 1;
            }
        }

        void AddRoomToList(string category, Room room)
        {
            switch (category)
            {
                case "A":
                    roomA.Add(room);
                    return;
                case "B":
                    roomB.Add(room);
                    return;
                default:
                    roomC.Add(room);
                    return;
            }
        }

        void LoadButton()
        {
            var statusRoom = roomSelected.Status;

            btnGetRoom.Enabled = statusRoom;
            btnCancel.Enabled = !statusRoom;
            btnOrder.Enabled = !statusRoom;
        }

        void UpdateLabelList()
        {
            // cập nhật UI list
            foreach (Panel pnl in flpContent.Controls)
            {
                var lbl = pnl.Controls[1] as Label;

                if (lbl.Text == roomSelected.ID)
                {
                    lbl.ForeColor = roomSelected.Status ? COLOR_LABEL_ROOM_EMPTY : COLOR_LABEL_ROOM_NOTEMPTY;
                    break;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var category = cbpCategory.SelectedValue.ToString();
            var id = category + GetIDByCategory(category);
            var status = cbpStatus.SelectedValue.ToString() == EMPTY;
            decimal price = 0;
            if (!decimal.TryParse(txtPrice.Text, out price))
            {
                MessageBox.Show("Giá không hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var room = new Room()
            {
                Category = category,
                DateCount = 0,
                ID = id,
                Price = price,
                Status = status
            };

            // Add room to roomA, B, C
            AddRoomToList(category, room);

            // Add room to UI
            var pnl = new FlowLayoutPanel()
            {
                Width = WIDTH_BUTTON + 10,
                Height = HEIGHT_BUTTON + 30
            };
            var btn = new Button()
            {
                Width = WIDTH_BUTTON,
                Height = HEIGHT_BUTTON,
                BackgroundImage = new Bitmap("./../../Resources/Room1.png"),
                BackgroundImageLayout = ImageLayout.Stretch
            };
            var lbl = new Label()
            {
                Text = room.ID,
                AutoSize = false,
                Width = WIDTH_BUTTON,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = status ? COLOR_LABEL_ROOM_EMPTY : COLOR_LABEL_ROOM_NOTEMPTY
            };

            // Load detail
            txtID.Text = room.ID;
            txtDateCount.Text = "0";

            btn.Tag = room;
            btn.Click += Btn_Click;

            pnl.Controls.Add(btn);
            pnl.Controls.Add(lbl);
            flpContent.Controls.Add(pnl);

            buttonSelected = btn;
            roomSelected = room;

            LoadButton();
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            buttonSelected = sender as Button;
            roomSelected = buttonSelected.Tag as Room;

            txtID.Text = roomSelected.ID;
            txtPrice.Text = roomSelected.Price.ToString();
            cbpCategory.SelectedIndex = categoies.IndexOf(roomSelected.Category);
            cbpStatus.SelectedIndex = roomSelected.Status ? 0 : 1;
            txtDateCount.Text = roomSelected.DateCount.ToString();

            LoadButton();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            var statusRoom = roomSelected.Status;
            int dateCount = 0;

            if (!int.TryParse(txtDateCount.Text, out dateCount))
            {
                MessageBox.Show("Số ngày đặt không hợp lệ!");
                return;
            }

            // Nếu phòng trống và số ngày  > 0
            if (!statusRoom)
            {
                MessageBox.Show("Phòng đã có người!");
                return;
            }
            if (dateCount <= 0)
            {
                MessageBox.Show("Số ngày đặt không hợp lệ!");
                return;
            }

            roomSelected.Status = false;
            roomSelected.DateCount = dateCount;

            // cập nhật UI list
            UpdateLabelList();

            // cập nhật comboBox
            cbpStatus.SelectedIndex = roomSelected.Status ? 0 : 1;

            LoadButton();

            MessageBox.Show("Đặt phòng thành công!");
        }

        private void btn_Click_1(object sender, EventArgs e)
        {
            var price = roomSelected.DateCount * roomSelected.Price;

            // cập nhật List
            roomSelected.Status = true;
            roomSelected.DateCount = 0;

            // cập nhật comboBox
            cbpStatus.SelectedIndex = roomSelected.Status ? 0 : 1;
            txtDateCount.Text = "0";

            // UI list
            UpdateLabelList();
            // Load button
            LoadButton();

            MessageBox.Show($"Số tiền cần thanh toán của bạn là: {price.ToString("#,##")} VND");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn hủy phòng!", "", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                // cập nhật List
                roomSelected.Status = true;
                roomSelected.DateCount = 0;

                // cập nhật comboBox
                cbpStatus.SelectedIndex = roomSelected.Status ? 0 : 1;
                txtDateCount.Text = "0";

                // UI list
                UpdateLabelList();
                // Load button
                LoadButton();
            }
        }
    }
}
